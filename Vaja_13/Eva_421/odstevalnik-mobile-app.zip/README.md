# Odštevalnik – Mobilna aplikacija (React.js)

Sodobna mobilna aplikacija za odštevanje dni do dogodkov, kalkulator razlike med datumi ter pregled preteklih dogodkov.

## Zagon projekta

1. Razširite arhiv v delovno mapo.
2. Odprite terminal v mapi projekta in namestite pakete:
   ```bash
   npm install
   ```
3. Zaženite aplikacijo:
   ```bash
   npm run dev
   ```
